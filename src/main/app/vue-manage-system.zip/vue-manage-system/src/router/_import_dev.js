module.exports = () => import(/* webpackChunkName: "editor" */ '../components/page/VueEditor'  + '.vue')

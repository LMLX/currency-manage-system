// export function checkToken() {
//     // checkLoginOut
//     this.$post("/base/user/checkLoginOut", {}).then(function (response) {
//         if(0 === response.status ){
//             return response.data
//         } else {
//             return false;
//         }
//     })
// }
